
# Sample Poster: Visualizing Measles Incidence in the USA (1928–2001)

This poster is intended as a pedagogical example for the 2025 course CSC3107 Information Visualization at the Singapore Institute of Technology.

The poster and any other material in this GitHub repo is published under the [CC BY-SA 4.0 license](https://creativecommons.org/licenses/by-sa/4.0/deed.en).
